function registraPagamento(){
    alert('Pagamento registrado!')
}